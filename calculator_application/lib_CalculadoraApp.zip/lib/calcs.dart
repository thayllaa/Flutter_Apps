// ignore_for_file: non_constant_identifier_names

class Calculations {
  double add(double B1, double B2) {
    return B1 + B2;
  }

  double subtract(double B1, double B2) {
    return B1 - B2;
  }

  double multiply(double B1, double B2) {
    return B1 * B2;
  }

  double divide(double B1, double B2) {
    return B1 / B2;
  }
}
